package com.example.myapp

import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private lateinit var questionTextView: TextView
    private lateinit var timerTextView: TextView
    private lateinit var resultTextView: TextView
    private lateinit var optionButtons: List<Button>
    private var currentQuestionIndex = 0
    private var score = 0
    private var timer: CountDownTimer? = null

    private val questions = listOf(
        Question("What is the capital of France?", listOf("Paris", "London", "Berlin", "Rome"), 0),
        Question("What is the capital of the UK?", listOf("Madrid", "London", "Vienna", "Prague"), 1),
        Question("What is the capital of Germany?", listOf("Lisbon", "Oslo", "Berlin", "Athens"), 2),
        Question("What is the capital of Italy?", listOf("Rome", "Milan", "Naples", "Florence"), 0),
        Question("What is the capital of Spain?", listOf("Barcelona", "Madrid", "Seville", "Valencia"), 1)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        questionTextView = findViewById(R.id.textViewQuestion)
        timerTextView = findViewById(R.id.textViewTimer)
        resultTextView = findViewById(R.id.textViewResult)

        optionButtons = listOf(
            findViewById(R.id.buttonOption1),
            findViewById(R.id.buttonOption2),
            findViewById(R.id.buttonOption3),
            findViewById(R.id.buttonOption4)
        )

        loadQuestion()
    }

    private fun loadQuestion() {
        if (currentQuestionIndex >= questions.size) {
            resultTextView.text = "Quiz finished! Your score: $score/${questions.size}"
            optionButtons.forEach { it.isEnabled = false }
            timerTextView.text = ""
            return
        }

        val question = questions[currentQuestionIndex]
        questionTextView.text = question.text
        optionButtons.forEachIndexed { index, button ->
            button.text = question.options[index]
            button.setOnClickListener {
                timer?.cancel()
                checkAnswer(index)
            }
        }

        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(10000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerTextView.text = "Time left: ${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                resultTextView.text = "Time's up!"
                nextQuestionDelayed()
            }
        }.start()
    }

    private fun checkAnswer(selectedIndex: Int) {
        val correct = selectedIndex == questions[currentQuestionIndex].correctAnswerIndex
        resultTextView.text = if (correct) "Correct!" else "Wrong!"
        if (correct) score++
        nextQuestionDelayed()
    }

    private fun nextQuestionDelayed() {
        optionButtons.forEach { it.isEnabled = false }
        currentQuestionIndex++
        Handler().postDelayed({
            resultTextView.text = ""
            optionButtons.forEach { it.isEnabled = true }
            loadQuestion()
        }, 1500)
    }

    data class Question(val text: String, val options: List<String>, val correctAnswerIndex: Int)
}
